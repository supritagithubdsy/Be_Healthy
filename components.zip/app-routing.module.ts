import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TipsComponent } from './components/home/tips/tips.component';
import { HomeComponent } from './components/home/home.component';
import { ContactUsComponent } from './components/home/contact-us/contact-us.component';
import { AboutUsComponent } from './components/home/about-us/about-us.component';
import { DailyExcersiseComponent } from './components/home/daily-excersise/daily-excersise.component';
import { RegisterComponent } from './components/home/register/register.component';
import { LoginComponent } from './components/home/login/login.component';
import { TipsDetailComponent } from './components/home/tips/tips-card/tips-detail/tips-detail.component';

const routes: Routes = [
  {path: "",component: HomeComponent},
  {path: "tips",component: TipsComponent},
  {path: "contact",component: ContactUsComponent},
  {path: "about",component: AboutUsComponent},
  {path: "daily-excercise",component: DailyExcersiseComponent},
  {path: "register",component: RegisterComponent},
  {path: "login",component: LoginComponent},
  {path: "tips/details/:id",component: TipsDetailComponent}

  // {path: "contact-us",component: ContactUsComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
