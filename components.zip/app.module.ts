import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { MatSidenavModule } from '@angular/material/sidenav';
import {MatToolbarModule} from '@angular/material/toolbar';
import { MatCommonModule } from '@angular/material/core';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { HttpClient, HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TipsComponent } from './components/home/tips/tips.component';
import { HomeComponent } from './components/home/home.component';
import { DailyExcersiseComponent } from './components/home/daily-excersise/daily-excersise.component';
import { AboutUsComponent } from './components/home/about-us/about-us.component';
import { ContactUsComponent } from './components/home/contact-us/contact-us.component';
import { TipsCardComponent } from './components/home/tips/tips-card/tips-card.component';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './components/home/login/login.component';
import { RegisterComponent } from './components/home/register/register.component';
import { TipsDetailComponent } from './components/home/tips/tips-card/tips-detail/tips-detail.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    TipsComponent,
    HomeComponent,
    DailyExcersiseComponent,
    AboutUsComponent,
    ContactUsComponent,
    TipsCardComponent,
    LoginComponent,
    RegisterComponent,
    TipsDetailComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatSidenavModule,
    MatToolbarModule,
    FormsModule,
    HttpClientModule,
    MatCommonModule,
    MatCardModule,
    MatListModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
