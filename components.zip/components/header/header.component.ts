import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import {MatSidenav} from '@angular/material/sidenav';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  @ViewChild('sidenav')
  sidenav!: MatSidenav;


  opened: boolean=false;
  constructor( public router: Router) { }
  userLoggedIn:boolean=true;
  firstName:any;
  ngOnInit(): void {
    const val =localStorage.getItem('userLoggedIn');
    console.log('userLoggedIn',val)
    const name= localStorage.getItem('firstName');
    this.firstName=name;

    if(val=='1'){
      this.userLoggedIn=false;
    }
  }
  clickHandler() {
    this.sidenav.close();
  }

  logout(){
    localStorage.setItem("userLoggedIn",'0');
    this.router.navigateByUrl('/');
    window.location.reload();
  }


}
