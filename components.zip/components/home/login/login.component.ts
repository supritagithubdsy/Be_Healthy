import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from 'src/app/models/user';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  login: Login = {
    email: '',
    mobile: '',
    password: '',
  };
  userLoggedIn: boolean = false;
  constructor(
    private userService: UserService,
    private router : Router
    ) {}

  ngOnInit(): void {
    const  userLoggedIn = localStorage.getItem('userLoggedIn');
    if(userLoggedIn=='1'){
      this.router.navigateByUrl('');
    }
  }

  userLogin() {
    this.userService.login(this.login).subscribe((data: any) => {
      console.log(data);
      if(data.status=='SUCCESS'){
        this.userLoggedIn=true;
        localStorage.setItem("userLoggedIn",'1');
        localStorage.setItem("firstName",data.firstName);
        localStorage.setItem("lastName",data.lastName);
        localStorage.setItem("email",this.login.email);
        // this.toastrService.success('Login Successfully');
        location.reload()
        this.router.navigateByUrl('popular-places');
        // window.location.reload();
      }
    });
  }
}

