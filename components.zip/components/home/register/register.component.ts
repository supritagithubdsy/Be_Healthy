import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Registration } from 'src/app/models/user';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  register: Registration ={
    firstName: '',
    lastName: '',
    email: '',
    mobile: '',
    password: '',
    city: '',
    zip: ''
  };
  constructor(
    private userService: UserService,
    private router : Router
  ) { }

  ngOnInit(): void {
  }
  registeration(){
    this.userService.registration(this.register).subscribe((data: any) => {
      console.log(data);
      if(data.status=='SUCCESS'){
        this.router.navigateByUrl('login');
      }
    });
  }

}

