import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daily-excersise',
  templateUrl: './daily-excersise.component.html',
  styleUrls: ['./daily-excersise.component.scss']
})
export class DailyExcersiseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
