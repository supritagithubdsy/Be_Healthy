import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DailyExcersiseComponent } from './daily-excersise.component';

describe('DailyExcersiseComponent', () => {
  let component: DailyExcersiseComponent;
  let fixture: ComponentFixture<DailyExcersiseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DailyExcersiseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DailyExcersiseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
