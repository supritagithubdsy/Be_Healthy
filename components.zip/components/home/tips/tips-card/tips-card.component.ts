import { Component, OnInit } from '@angular/core';
import { PlaceService } from 'src/app/services/place.service';

@Component({
  selector: 'app-tips-card',
  templateUrl: './tips-card.component.html',
  styleUrls: ['./tips-card.component.scss']
})
export class TipsCardComponent implements OnInit {

  constructor(private placeService: PlaceService) { }

  ngOnInit(): void {
    this.getPopularTips();
  }

  cars = ["Saab", "Volvo", "BMW", "Tata", "Hyundai", "Tesla"];
  longText = `The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog
    from Japan. A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was
    originally bred for hunting.`;

placeData:any;
getPopularTips(){
  this.placeService.getAllTips().subscribe((data:any)=>{
    console.log(data);
    this.placeData=data;
  })
}

tipsDetailPage(data:any){
  const url = `http://localhost:4200/tips/details/${data.id}`;
    window.open(url, "_blank");
}

}
