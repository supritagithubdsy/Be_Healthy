import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PlaceService } from 'src/app/services/place.service';

@Component({
  selector: 'app-tips-detail',
  templateUrl: './tips-detail.component.html',
  styleUrls: ['./tips-detail.component.scss']
})
export class TipsDetailComponent implements OnInit {
  testId: string | undefined;

  constructor(private route: ActivatedRoute, private placeService: PlaceService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.testId = params['id']; // Access the 'id' parameter from the URL
      console.log('Test ID:', this.testId);
      this.getPopularTips(this.testId);
    });
  }

  placeData:any;
getPopularTips(id:any){
  this.placeService.getTipsById(id).subscribe((data:any)=>{
    console.log(data);
    this.placeData=data;
  })
}

}
