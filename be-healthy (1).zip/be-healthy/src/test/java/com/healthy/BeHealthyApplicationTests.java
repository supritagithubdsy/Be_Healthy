package com.healthy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeHealthyApplicationTests {

	@Test
	void contextLoads() {
	}

}
