/**
 * 
 */
package com.healthy.util;

import at.favre.lib.crypto.bcrypt.BCrypt;

/**
 * @author Suprita
 *
 */
public class Hashing {

	public static String generateHash(String password) {
		return BCrypt.withDefaults().hashToString(12, password.toCharArray());
	}

	public static boolean verifyHash(String password, String hashPwd) {
		BCrypt.Result result = BCrypt.verifyer().verify(password.toCharArray(), hashPwd);
		return result.verified;
	}

}
