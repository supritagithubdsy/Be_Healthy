package com.healthy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.healthy.entity.User;

public interface UserRepository extends JpaRepository<User, Integer> {

	@Query(value = "select * from User where email=:emailId OR mobile=:mobileNo", nativeQuery = true)
	public User getUserByEmailOrMobile(String emailId, String mobileNo);
}
