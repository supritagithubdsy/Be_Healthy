package com.healthy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.healthy.entity.HealthyTips;

public interface HealthyTipsRepository extends JpaRepository<HealthyTips, Integer> {

	public List<HealthyTips> findBytipsCode(String tipsCode);
}
