package com.healthy.service.impl;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthy.entity.User;
import com.healthy.request.LoginRequest;
import com.healthy.response.LoginResponse;
import com.healthy.service.UserService;
import com.healthy.util.Hashing;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private com.healthy.repository.UserRepository userRepository;

	@Override
	public User register(User user) {
		user.setPassword(Hashing.generateHash(user.getPassword()));
		User userSaved = userRepository.save(user);
		return userSaved;
	}

	@Override
	public User getUser(Integer id) {
		Optional<User> user = userRepository.findById(id);
		return user.get();
	}

	@Override
	public User updateUser(User user) {
		if (StringUtils.isNotEmpty(user.getPassword())) {
			user.setPassword(Hashing.generateHash(user.getPassword()));
		}
		User userSaved = userRepository.save(user);
		return userSaved;
	}

	@Override
	public String deleteUser(Integer id) {
		userRepository.deleteById(id);
		return "Deleted Successfully";
	}

	@Override
	public LoginResponse login(LoginRequest request) {
		LoginResponse response = new LoginResponse();

		try {
			String email = request.getEmail();
			String mobile = request.getMobile();
			User user = userRepository.getUserByEmailOrMobile(email, mobile);
			if (user != null) {
				if (Hashing.verifyHash(request.getPassword(), user.getPassword())) {
					response.setFirstName(user.getFirstName());
					response.setLastName(user.getLastName());
					response.setMessage("User Logged In Successfully");
					response.setStatus("SUCCESS");
				} else {
					response.setFirstName(user.getFirstName());
					response.setLastName(user.getLastName());
					response.setMessage("Username or Password Invalid");
					response.setStatus("FAILED");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

}
