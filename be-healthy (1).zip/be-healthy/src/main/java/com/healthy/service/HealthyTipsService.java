package com.healthy.service;

import java.util.List;

import com.healthy.entity.HealthyTips;

public interface HealthyTipsService {

	public HealthyTips add(HealthyTips place);

	public HealthyTips getplace(Integer id);

	public HealthyTips updatePlace(HealthyTips place);

	public String deletePlace(Integer id);

	public List<HealthyTips> getPlaceByCode(String cityCode);

	public List<HealthyTips> getAllPlace();

}
