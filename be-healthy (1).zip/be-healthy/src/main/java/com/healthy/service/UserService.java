package com.healthy.service;

import com.healthy.entity.User;
import com.healthy.request.LoginRequest;
import com.healthy.response.LoginResponse;

public interface UserService {

	public User register(User user);

	public User getUser(Integer id);

	public User updateUser(User user);

	public String deleteUser(Integer id);

	public LoginResponse login(LoginRequest request);

}
