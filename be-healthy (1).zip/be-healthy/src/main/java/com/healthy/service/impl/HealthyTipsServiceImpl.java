package com.healthy.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthy.entity.HealthyTips;
import com.healthy.repository.HealthyTipsRepository;
import com.healthy.service.HealthyTipsService;

@Service
public class HealthyTipsServiceImpl implements HealthyTipsService {

	@Autowired
	private HealthyTipsRepository healthyTipsRepository;

	@Override
	public HealthyTips add(HealthyTips place) {
		return healthyTipsRepository.saveAndFlush(place);
	}

	@Override
	public HealthyTips getplace(Integer id) {
		HealthyTips place = healthyTipsRepository.findById(id).get();
		return place;
	}

	@Override
	public HealthyTips updatePlace(HealthyTips place) {
		HealthyTips placeSaved = healthyTipsRepository.saveAndFlush(place);
		return placeSaved;
	}

	@Override
	public String deletePlace(Integer id) {
		healthyTipsRepository.deleteById(id);
		return "Deleted Successfully";
	}

	@Override
	public List<HealthyTips> getPlaceByCode(String cityCode) {
		List<HealthyTips> placeList = healthyTipsRepository.findBytipsCode(cityCode);
		return placeList;
	}

	@Override
	public List<HealthyTips> getAllPlace() {
		return healthyTipsRepository.findAll();
	}

}
