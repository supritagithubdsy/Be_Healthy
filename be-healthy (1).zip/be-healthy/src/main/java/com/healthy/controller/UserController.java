package com.healthy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthy.entity.User;
import com.healthy.request.LoginRequest;
import com.healthy.response.LoginResponse;
import com.healthy.service.UserService;

@RestController()
@RequestMapping(value = "/user")
@CrossOrigin
public class UserController {

	@Autowired
	private UserService userService;

	@GetMapping(value = "/success")
	public String success() {
		return "Connection Successfull";
	}

	@PostMapping(value = "/register")
	public User addUser(@RequestBody User user) {
		User response = userService.register(user);
		return response;
	}

	@PostMapping(value = "/login")
	public LoginResponse login(@RequestBody LoginRequest request) {
		LoginResponse response = userService.login(request);
		return response;
	}

	@GetMapping(value = "/{id}")
	public User getUser(@PathVariable Integer id) {
		User response = userService.getUser(id);
		return response;
	}

	@PutMapping(value = "/update")
	public User updateUser(@RequestBody User user) {
		User response = userService.updateUser(user);
		return response;
	}

	@DeleteMapping(value = "/delete/{id}")
	public String deleteUser(@PathVariable Integer id) {
		String response = userService.deleteUser(id);
		return response;
	}

}
