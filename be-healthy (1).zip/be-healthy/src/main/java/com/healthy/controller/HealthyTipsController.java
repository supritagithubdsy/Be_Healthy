package com.healthy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthy.entity.HealthyTips;
import com.healthy.service.HealthyTipsService;

@RestController()
@RequestMapping(value = "/tips")
@CrossOrigin
public class HealthyTipsController {

	@Autowired
	private HealthyTipsService healthyTipsService;

	@GetMapping(value = "/success")
	public String success() {
		return "Connection Successfull";
	}

	@PostMapping(value = "/add")
	public HealthyTips addUser(@RequestBody HealthyTips tips) {
		HealthyTips response = healthyTipsService.add(tips);
		return response;
	}

	@GetMapping(value = "/{id}")
	public HealthyTips getPlace(@PathVariable Integer id) {
		HealthyTips response = healthyTipsService.getplace(id);
		return response;
	}

	@PutMapping(value = "/update")
	public HealthyTips updatePlace(@RequestBody HealthyTips tips) {
		HealthyTips response = healthyTipsService.updatePlace(tips);
		return response;
	}

	@DeleteMapping(value = "/delete/{id}")
	public String deletePlace(@PathVariable Integer id) {
		String response = healthyTipsService.deletePlace(id);
		return response;
	}

	@GetMapping(value = "/{code}")
	public List<HealthyTips> getPlaceByCode(@PathVariable String code) {
		List<HealthyTips> response = healthyTipsService.getPlaceByCode(code);
		return response;
	}

	@GetMapping(value = "/all")
	public List<HealthyTips> getAllPlace() {
		List<HealthyTips> response = healthyTipsService.getAllPlace();
		return response;
	}

}
