package com.healthy.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class HealthyTips {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String tipsName;
	private String description;
	private String image;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTipsName() {
		return tipsName;
	}
	public void setTipsName(String tipsName) {
		this.tipsName = tipsName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getTipsType() {
		return tipsType;
	}
	public void setTipsType(String tipsType) {
		this.tipsType = tipsType;
	}
	public String getTipsCode() {
		return tipsCode;
	}
	public void setTipsCode(String tipsCode) {
		this.tipsCode = tipsCode;
	}
	private String tipsType;
	@Override
	public String toString() {
		return "HealthyTips [id=" + id + ", tipsName=" + tipsName + ", description=" + description + ", image=" + image
				+ ", tipsType=" + tipsType + ", tipsCode=" + tipsCode + "]";
	}
	private String tipsCode;
}
