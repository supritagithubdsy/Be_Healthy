package com.healthy.request;

public class ExampleDto {

}
